// Extract the largest embedded PNG from the user's exact favicon.
const fs = require('node:fs');
const path = require('node:path');
const sharp = require('sharp');
const root = path.resolve(__dirname, '..');
const ico = fs.readFileSync(path.resolve(root, '../static/img/favicon.ico'));
const entries = Array.from({length:ico.readUInt16LE(4)}, (_,i) => {
  const p = 6 + i * 16;
  return {size:ico[p] || 256, bytes:ico.readUInt32LE(p+8), offset:ico.readUInt32LE(p+12)};
}).sort((a,b)=>b.size-a.size);
const best = entries[0];
const source = ico.subarray(best.offset,best.offset+best.bytes);
if (source.subarray(0,8).toString('hex') !== '89504e470d0a1a0a') throw new Error('Expected PNG-backed favicon');
const destination = path.join(root, 'custom_components/anma_cloud/brand');
(async () => {
  fs.mkdirSync(destination, {recursive:true});
  for (const [name,size] of [['icon.png',256],['icon@2x.png',512],['dark_icon.png',256],['dark_icon@2x.png',512]]) {
    await sharp(source,{density:600}).resize(size,size).png().toFile(path.join(destination,name));
  }
  console.log('Existing ANMA icon rendered at 256px and 512px for both themes.');
})().catch(error=>{console.error(error);process.exit(1);});
