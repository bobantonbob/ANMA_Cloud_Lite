"""Build translations and ZIP; no credentials, network or HA writes."""
import json
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile

ROOT = Path(__file__).resolve().parents[1]
COMPONENT = ROOT / 'custom_components/anma_cloud'


def translations():
    for language in ('uk', 'en'):
        path = COMPONENT / 'translations' / f'{language}.json'
        data = json.loads(path.read_text(encoding='utf-8'))
        options = data['options']
        init = options['step']['init']
        if language == 'uk':
            init['description'] = ('Натисніть поле та введіть частину назви або ID, наприклад bat. '
                'Результат містить назву, значення, одиниці та entity_id. '
                'Значення зчитані о {updated}; вони не оновлюються автоматично у відкритому списку. '
                'Для нового знімка виберіть «Оновити значення» внизу й натисніть «Надіслати». '
                'Вибір збережеться у чернетці. «Не використовувати» прибирає відповідну прив’язку.')
            init['data']['form_action'] = 'Наступний крок'
            init['data_description'] = {
                'invert_battery_power': 'ANMA: додатне значення — заряд, від’ємне — розряд. Поточний знак перевірте на наступному екрані.',
                'invert_grid_power': 'ANMA: додатне значення — імпорт, від’ємне — експорт.'}
            options['step']['review'] = {'title': 'Перевірка перед збереженням',
                'description': 'Значення станом на {updated}. Справа — результат перетворення одиниць та інверсії знака.\n\n{preview}',
                'menu_options': {'save': 'Зберегти прив’язки', 'edit': 'Повернутися до вибору', 'refresh': 'Оновити поточні значення'}}
            options['error'] = {'entity_not_found': 'Такої сутності немає. Виберіть наявну сутність зі списку.',
                'incompatible_source': 'Тип або одиниці цієї сутності не підходять для показника.',
                'self_reference': 'Не можна вибирати вихідний датчик ANMA як джерело ANMA.'}
            choices = {'review': 'Переглянути результат перед збереженням', 'refresh': 'Оновити значення у списках'}
        else:
            init['description'] = ('Open a field and type part of a name or entity ID, e.g. bat. '
                'Results show the name, value, unit and entity ID. Values were read at {updated}; '
                'an open list does not update automatically. Select “Refresh values” below and submit for a new snapshot. '
                'Your selections remain in the draft. “Not mapped” clears that mapping.')
            init['data']['form_action'] = 'Next step'
            init['data_description'] = {'invert_battery_power': 'ANMA: positive means charging; negative means discharging. Check the result on the next screen.',
                'invert_grid_power': 'ANMA: positive means import; negative means export.'}
            options['step']['review'] = {'title': 'Review before saving',
                'description': 'Values as of {updated}. The last column includes unit conversion and sign inversion.\n\n{preview}',
                'menu_options': {'save': 'Save mappings', 'edit': 'Back to selection', 'refresh': 'Refresh current values'}}
            options['error'] = {'entity_not_found': 'Entity not found. Select an existing entity from the list.',
                'incompatible_source': 'This entity type or unit is not compatible with the metric.',
                'self_reference': 'ANMA output entities cannot be used as ANMA sources.'}
            choices = {'review': 'Review before saving', 'refresh': 'Refresh values in the lists'}
        init['title'] = 'ANMA Cloud · Потоки енергії' if language == 'uk' else 'ANMA Cloud · Energy flow'
        init['description'] = ('**ANMA · Ваша енергія під контролем**\n\n{summary}\n\n---\n\n' if language == 'uk' else
                               '**ANMA · Your energy at a glance**\n\n{summary}\n\n---\n\n') + init['description']
        options['step']['review']['description'] = '{summary}\n\n---\n\n' + options['step']['review']['description']
        data['selector'] = {'form_action': {'options': choices}}
        choices['pairing'] = 'Підключення сайту ANMA' if language == 'uk' else 'Connect ANMA website'
        options['step']['pairing'] = {
            'title': 'ANMA · Підключення сайту' if language == 'uk' else 'ANMA · Website connection',
            'description': ('Спочатку збережіть вибрані джерела. Код дозволяє сайту читати лише ANMA-показники через Tailscale. '
                            'Новий код замінює попередній; успішне використання замінює ключ підключення сайту.' if language == 'uk' else
                            'Save your source mappings first. The code grants read-only access to ANMA metrics over Tailscale. '
                            'A new code replaces the previous one; redeeming it replaces the website connection credential.'),
            'menu_options': {'generate_code':'Створити код на 15 хвилин' if language == 'uk' else 'Generate 15-minute code',
                             'revoke':'Відкликати доступ сайту' if language == 'uk' else 'Revoke website access',
                             'edit':'Повернутися до сутностей' if language == 'uk' else 'Back to source selection'}}
        options['step']['generate_code'] = {'title':'ANMA · Код підключення' if language == 'uk' else 'ANMA · Pairing code',
            'description': ('## `{code}`\n\nКод діє 15 хвилин, до перезапуску HA або до першого використання. Передайте його власнику. '
                            'У кабінеті сайту потрібно ввести назву будинку, Tailscale IP цієї машини та код. Не публікуйте код. '
                            'Натисніть «Надіслати», щоб повернутися.' if language == 'uk' else
                            '## `{code}`\n\nValid for 15 minutes, until HA restarts, or until redeemed. Give it to the owner. '
                            'Enter the home name, this machine’s Tailscale IP and code on the website. Keep it private. Submit to return.')}
        options['step']['revoke'] = {'title':'Відкликати доступ?' if language == 'uk' else 'Revoke access?',
            'description': ('Після підтвердження сайт більше не отримуватиме дані. Сутності HA залишаться. Для відновлення потрібна повторна прив’язка.' if language == 'uk' else
                            'Confirm to stop the website reading data. HA entities remain. Re-pairing will be required to restore access.')}
        data['config']['abort'] = {'already_configured': 'ANMA Cloud уже налаштовано.' if language == 'uk' else 'ANMA Cloud is already configured.'}
        path.write_text(json.dumps(data, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
        if language == 'en':
            (COMPONENT / 'strings.json').write_text(path.read_text(encoding='utf-8'), encoding='utf-8')


def package():
    version = json.loads((COMPONENT / 'manifest.json').read_text(encoding='utf-8'))['version']
    target = ROOT.parent / f'ANMA_HA_Integration_v{version}.zip'
    with ZipFile(target, 'w', ZIP_DEFLATED) as archive:
        for path in sorted(COMPONENT.rglob('*')):
            if path.is_file() and '__pycache__' not in path.parts:
                archive.write(path, path.relative_to(ROOT))
        archive.write(ROOT / 'README_UA.md', 'README_UA.md')
    print(target)


if __name__ == '__main__':
    translations()
    package()
