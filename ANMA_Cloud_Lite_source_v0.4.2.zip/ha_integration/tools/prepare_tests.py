"""Fetch the small test dependency from official PyPI, verify its hash."""
import hashlib
import json
import subprocess
import sys
import urllib.request
from pathlib import Path

root = Path(__file__).resolve().parents[1]
folder = root / '.test-deps'
folder.mkdir(exist_ok=True)
with urllib.request.urlopen('https://pypi.org/pypi/voluptuous/0.15.2/json', timeout=15) as response:
    metadata = json.load(response)
wheel = next(item for item in metadata['urls'] if item['filename'].endswith('.whl'))
with urllib.request.urlopen(wheel['url'], timeout=15) as response:
    content = response.read()
assert hashlib.sha256(content).hexdigest() == wheel['digests']['sha256']
path = folder / wheel['filename']
path.write_bytes(content)
subprocess.run([sys.executable, '-m', 'pip', 'install', '--no-index', '--no-deps',
                '--disable-pip-version-check', '--target', str(folder), str(path)], check=True)
